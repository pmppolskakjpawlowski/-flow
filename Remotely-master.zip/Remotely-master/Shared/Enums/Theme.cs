﻿namespace Remotely.Shared.Enums
{
    public enum Theme
    {
        Dark,
        Light
    }
}
