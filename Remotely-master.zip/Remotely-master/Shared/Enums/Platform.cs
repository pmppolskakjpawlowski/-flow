﻿namespace Remotely.Shared.Enums
{
    public enum Platform
    {
        Windows,
        Linux,
        MacOS,
        Unknown
    }
}
