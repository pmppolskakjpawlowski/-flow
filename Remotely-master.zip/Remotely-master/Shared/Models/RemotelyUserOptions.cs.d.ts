	interface remotelyUserOptions {
		displayName: string;
		commandModeShortcutPSCore: string;
		commandModeShortcutWinPS: string;
		commandModeShortcutCMD: string;
		commandModeShortcutBash: string;
		theme: any;
	}
