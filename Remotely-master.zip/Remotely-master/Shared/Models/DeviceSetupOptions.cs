﻿namespace Remotely.Shared.Models
{
    public class DeviceSetupOptions
    {
        public string DeviceAlias { get; set; }
        public string DeviceGroupName { get; set; }
        public string DeviceID { get; set; }
        public string OrganizationID { get; set; }
    }
}
