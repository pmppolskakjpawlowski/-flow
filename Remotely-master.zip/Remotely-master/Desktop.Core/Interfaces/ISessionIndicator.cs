﻿namespace Remotely.Desktop.Core.Interfaces
{
    public interface ISessionIndicator
    {
        void Show();
    }
}
