﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Remotely.Desktop.Core.Enums
{
    public enum ButtonAction
    {
        Down,
        Up
    }
}
