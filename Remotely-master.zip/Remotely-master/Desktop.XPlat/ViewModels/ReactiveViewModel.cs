﻿using ReactiveUI;

namespace Remotely.Desktop.XPlat.ViewModels
{
    public class ReactiveViewModel : ReactiveObject
    {
    }
}
