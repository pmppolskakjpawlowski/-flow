﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Remotely.Server.Components.TreeView
{
    public enum TreeItemType
    {
        Folder,
        Item
    }
}
