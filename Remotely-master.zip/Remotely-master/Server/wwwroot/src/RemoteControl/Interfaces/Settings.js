export {};
//# sourceMappingURL=Settings.js.map