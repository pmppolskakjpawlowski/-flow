﻿import { BaseDtoType } from "../Enums/BaseDtoType.js";

export interface BaseDto {
    DtoType: BaseDtoType;
}