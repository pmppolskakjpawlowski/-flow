﻿export interface Settings {
    displayName: string;
    streamModeEnabled: boolean;
}