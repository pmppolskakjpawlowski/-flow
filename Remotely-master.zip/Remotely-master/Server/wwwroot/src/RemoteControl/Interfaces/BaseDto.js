export {};
//# sourceMappingURL=BaseDto.js.map