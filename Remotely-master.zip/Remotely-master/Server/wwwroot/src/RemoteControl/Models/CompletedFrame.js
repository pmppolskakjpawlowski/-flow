export class CompletedFrame {
}
//# sourceMappingURL=CompletedFrame.js.map