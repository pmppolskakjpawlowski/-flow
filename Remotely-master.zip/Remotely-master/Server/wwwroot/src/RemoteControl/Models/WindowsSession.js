export class WindowsSession {
}
//# sourceMappingURL=WindowsSession.js.map