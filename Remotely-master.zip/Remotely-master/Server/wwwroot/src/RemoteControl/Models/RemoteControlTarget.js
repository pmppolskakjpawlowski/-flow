export class RemoteControlTarget {
}
//# sourceMappingURL=RemoteControlTarget.js.map