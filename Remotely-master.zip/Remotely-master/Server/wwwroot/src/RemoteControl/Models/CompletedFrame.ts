﻿import { CaptureFrameDto } from "../Interfaces/Dtos.js";

export class CompletedFrame {
    ImageContent: ImageBitmap;
    FrameData: CaptureFrameDto;
}