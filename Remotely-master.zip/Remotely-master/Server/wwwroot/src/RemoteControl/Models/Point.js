export {};
//# sourceMappingURL=Point.js.map