export {};
//# sourceMappingURL=HubConnection.js.map