export var WindowsSessionType;
(function (WindowsSessionType) {
    WindowsSessionType[WindowsSessionType["Console"] = 0] = "Console";
    WindowsSessionType[WindowsSessionType["RDP"] = 1] = "RDP";
})(WindowsSessionType || (WindowsSessionType = {}));
//# sourceMappingURL=WindowsSessionType.js.map