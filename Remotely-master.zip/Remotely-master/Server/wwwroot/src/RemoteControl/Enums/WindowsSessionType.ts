﻿export enum WindowsSessionType {
    Console = 0,
    RDP = 1
}