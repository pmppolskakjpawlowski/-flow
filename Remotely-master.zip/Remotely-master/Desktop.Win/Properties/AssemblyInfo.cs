﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Remotely.Desktop.Win.Tests")]